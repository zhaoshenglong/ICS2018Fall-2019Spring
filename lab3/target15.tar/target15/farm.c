/* This function marks the start of the farm */
int start_farm()
{
    return 1;
}

unsigned getval_280()
{
    return 2421720912U;
}

void setval_111(unsigned *p)
{
    *p = 3284633928U;
}

void setval_315(unsigned *p)
{
    *p = 2445773128U;
}

unsigned addval_168(unsigned x)
{
    return x + 3281049601U;
}

unsigned getval_230()
{
    return 3251079496U;
}

unsigned addval_236(unsigned x)
{
    return x + 3284633928U;
}

unsigned getval_317()
{
    return 2425378896U;
}

void setval_277(unsigned *p)
{
    *p = 3281000684U;
}

/* This function marks the middle of the farm */
int mid_farm()
{
    return 1;
}

/* Add two arguments */
long add_xy(long x, long y)
{
    return x+y;
}

void setval_183(unsigned *p)
{
    *p = 3286288712U;
}

void setval_227(unsigned *p)
{
    *p = 2430634312U;
}

unsigned getval_117()
{
    return 3374367401U;
}

unsigned addval_468(unsigned x)
{
    return x + 3531918989U;
}

void setval_243(unsigned *p)
{
    *p = 3286272332U;
}

unsigned getval_372()
{
    return 3229926041U;
}

void setval_265(unsigned *p)
{
    *p = 3281044097U;
}

unsigned getval_161()
{
    return 3222851209U;
}

unsigned addval_281(unsigned x)
{
    return x + 3247492745U;
}

unsigned getval_357()
{
    return 3687109001U;
}

unsigned addval_192(unsigned x)
{
    return x + 2425668233U;
}

void setval_342(unsigned *p)
{
    *p = 3281179017U;
}

unsigned addval_289(unsigned x)
{
    return x + 3374370505U;
}

unsigned addval_276(unsigned x)
{
    return x + 3682913929U;
}

unsigned addval_328(unsigned x)
{
    return x + 2430634312U;
}

void setval_316(unsigned *p)
{
    *p = 3675836041U;
}

unsigned addval_235(unsigned x)
{
    return x + 3284306912U;
}

unsigned getval_283()
{
    return 2447411528U;
}

unsigned getval_162()
{
    return 2429454722U;
}

unsigned addval_199(unsigned x)
{
    return x + 2464188744U;
}

unsigned addval_324(unsigned x)
{
    return x + 3675836809U;
}

unsigned getval_196()
{
    return 3227569801U;
}

void setval_318(unsigned *p)
{
    *p = 3375944072U;
}

unsigned getval_482()
{
    return 3674788233U;
}

unsigned addval_294(unsigned x)
{
    return x + 2430634824U;
}

unsigned addval_275(unsigned x)
{
    return x + 3229929881U;
}

unsigned addval_237(unsigned x)
{
    return x + 2428668344U;
}

unsigned addval_436(unsigned x)
{
    return x + 3678982537U;
}

void setval_433(unsigned *p)
{
    *p = 3375940233U;
}

void setval_193(unsigned *p)
{
    *p = 3523789513U;
}

unsigned getval_473()
{
    return 3281047945U;
}

unsigned getval_125()
{
    return 3353381192U;
}

/* This function marks the end of the farm */
int end_farm()
{
    return 1;
}
